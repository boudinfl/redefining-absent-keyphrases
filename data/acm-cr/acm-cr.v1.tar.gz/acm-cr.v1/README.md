# ACM-CR: a test collection for context-aware citation recommendation

This dataset was constructed for the paper:

 - **Redefining Absent Keyphrases and their Effect on Retrieval Effectiveness.**
   Florian Boudin, Ygor Gallina.
   Annual Conference of the North American Chapter of the Association for Computational Linguistics (NAACL-HLT), 2021.

The test collection is in TREC format for ease of use in IR toolkits.

topics/acm-cr-30.topics - queries (169 citation contexts extracted from 30 IR related papers)
qrels/acm-cr-30.qrels - relevance judgments (481 cited documents)
docs/acm-102k.trec.gz - collection of 102,411 documents (converted from BibTeX entries to TREC format)